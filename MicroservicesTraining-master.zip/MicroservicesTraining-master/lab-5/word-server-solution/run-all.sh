mvn spring-boot:run -Dspring-boot.run.profiles=subject &
mvn spring-boot:run -Dspring-boot.run.profiles=verb &
mvn spring-boot:run -Dspring-boot.run.profiles=article &
mvn spring-boot:run -Dspring-boot.run.profiles=adjective &
mvn spring-boot:run -Dspring-boot.run.profiles=noun 
